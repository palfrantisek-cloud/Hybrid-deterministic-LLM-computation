#!/usr/bin/env python3
"""Deterministic core: exact, reproducible math for an LLM to call and to verify against.

Commands (all print JSON):
  calc   "<expr>"                         exact value of an expression
  check  "<expr>" "<claimed>"             does expr equal the claimed value?
  solve  "<equation>" [var]               solve, then verify each root by substitution
  steps  <file.json | ->                  verify a list of {"label","expr","claimed"} steps
  date   "<YYYY-MM-DD>" [+/-days | "<YYYY-MM-DD>"]   date arithmetic / difference

Input is parsed with a whitelisted AST walker (no eval), so it is safe on arbitrary text.
Syntax: + - * / ** ^ % ( ), 15% -> 0.15, decimals are exact (0.1 + 0.2 == 3/10).
Functions: sqrt, cbrt, abs, exp, log, ln, log10, sin, cos, tan, asin, acos, atan,
factorial, floor, ceil, round, min, max, gcd, lcm, binomial. Constants: pi, e.
"""
import ast, json, re, sys
from datetime import date, timedelta

try:
    import sympy as sp
except ImportError:  # pragma: no cover
    print(json.dumps({"ok": False, "error": "sympy missing: pip install sympy"}))
    sys.exit(2)

MAX_EXP = 10_000          # guard against 10**10**10 style blow-ups
TOL = sp.Rational(1, 10**9)  # tolerance when the claim is a rounded decimal

FUNCS = {
    "sqrt": sp.sqrt, "cbrt": lambda x: sp.root(x, 3), "abs": sp.Abs, "exp": sp.exp,
    "log": lambda x, b=None: sp.log(x) if b is None else sp.log(x, b), "ln": sp.log,
    "log10": lambda x: sp.log(x, 10), "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "factorial": sp.factorial,
    "floor": sp.floor, "ceil": sp.ceiling,
    "round": lambda x, n=0: _round(x, n),
    "min": sp.Min, "max": sp.Max, "gcd": sp.gcd, "lcm": sp.lcm, "binomial": sp.binomial,
}
CONSTS = {"pi": sp.pi, "e": sp.E, "E": sp.E}


def _round(x, n=0):
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-int(n))
    return sp.Rational(str(Decimal(str(sp.N(x, 50))).quantize(q, rounding=ROUND_HALF_UP)))


class Unsafe(ValueError):
    pass


def _pre(text: str) -> str:
    t = text.strip().replace("^", "**").replace("×", "*").replace("÷", "/").replace("−", "-")
    t = re.sub(r"(?<=\d),(?=\d{3}\b)", "", t)            # 1,000 -> 1000
    t = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", t)   # 15% -> (15/100)
    t = re.sub(r"(\d)\s*(?=[A-Za-z(])", r"\1*", t)          # 2x -> 2*x, 3(4) -> 3*(4)
    t = re.sub(r"\)\s*(?=[\w(])", ")*", t)                    # (a)(b) -> (a)*(b)
    return t


def _to_sym(node, symbols):
    if isinstance(node, ast.Expression):
        return _to_sym(node.body, symbols)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return sp.Rational(str(node.value)) if isinstance(node.value, float) else sp.Integer(node.value)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        v = _to_sym(node.operand, symbols)
        return v if isinstance(node.op, ast.UAdd) else -v
    if isinstance(node, ast.BinOp):
        a, b = _to_sym(node.left, symbols), _to_sym(node.right, symbols)
        op = node.op
        if isinstance(op, ast.Add): return a + b
        if isinstance(op, ast.Sub): return a - b
        if isinstance(op, ast.Mult): return a * b
        if isinstance(op, ast.Div):
            if b == 0: raise ZeroDivisionError("division by zero")
            return a / b
        if isinstance(op, ast.Mod): return sp.Mod(a, b)
        if isinstance(op, ast.FloorDiv): return sp.floor(a / b)
        if isinstance(op, ast.Pow):
            if b.is_number and abs(sp.N(b)) > MAX_EXP:
                raise Unsafe("exponent too large")
            return a ** b
    if isinstance(node, ast.Name):
        if node.id in CONSTS: return CONSTS[node.id]
        if re.fullmatch(r"[A-Za-z_]\w{0,15}", node.id):
            return symbols.setdefault(node.id, sp.Symbol(node.id))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCS and not node.keywords:
        return FUNCS[node.func.id](*[_to_sym(a, symbols) for a in node.args])
    raise Unsafe(f"unsupported syntax: {ast.dump(node)[:60]}")


def parse(text, symbols=None):
    symbols = {} if symbols is None else symbols
    return _to_sym(ast.parse(_pre(text), mode="eval"), symbols)


def _fmt(v):
    v = sp.nsimplify(v) if v.is_Float else sp.simplify(v)
    out = {"exact": str(v)}
    if v.is_number:
        out["decimal"] = str(sp.N(v, 15))
    return out


def _equal(a, b):
    """True if equal exactly, or if b is a rounded decimal of a (reported as 'rounded')."""
    d = sp.simplify(a - b)
    if d == 0:
        return True, "exact"
    if d.is_number:
        diff = abs(sp.N(d, 50))
        # accept a claim rounded to the number of decimals it shows
        return (diff <= TOL, "numeric") if diff <= TOL else (False, "mismatch")
    return False, "not provably equal"


def cmd_calc(expr):
    v = parse(expr)
    return {"ok": True, "mode": "deterministic", "input": expr, **_fmt(v)}


def cmd_check(expr, claimed):
    a, b = parse(expr), parse(claimed)
    same, how = _equal(a, b)
    if not same and b.is_number and a.is_number and "." in claimed:
        # claimed may be rounded, e.g. 3.33 for 10/3: accept if it matches at its own precision.
        # Integer claims must match exactly (so "3" never passes for 3.4).
        m = re.search(r"\.(\d+)", claimed)
        places = len(m.group(1)) if m else 0
        if abs(sp.N(a - b, 50)) <= sp.Rational(1, 2 * 10**places):
            same, how = True, f"rounded to {places} dp"
    return {"ok": True, "verified": bool(same), "how": how, "input": expr,
            "claimed": claimed, "computed": _fmt(a)}


def cmd_solve(eq, var=None):
    syms = {}
    if "=" in eq and "==" not in eq:
        lhs, rhs = eq.split("=", 1)
        expr = parse(lhs, syms) - parse(rhs, syms)
    else:
        expr = parse(eq.replace("==", "-(") + (")" if "==" in eq else ""), syms)
    if not syms:
        raise Unsafe("no variable to solve for")
    x = syms[var] if var else sorted(syms.values(), key=str)[0]
    roots = sp.solve(expr, x)
    checked = [{"root": _fmt(r), "substitution_check": sp.simplify(expr.subs(x, r)) == 0} for r in roots]
    return {"ok": True, "variable": str(x), "solutions": checked,
            "verified": bool(roots) and all(c["substitution_check"] for c in checked)}


def cmd_steps(src):
    data = json.load(sys.stdin if src == "-" else open(src, encoding="utf-8"))
    results = []
    for i, s in enumerate(data, 1):
        try:
            r = cmd_check(s["expr"], str(s["claimed"]))
        except Exception as ex:  # noqa: BLE001
            r = {"verified": False, "error": str(ex)}
        r["label"] = s.get("label", f"step {i}")
        results.append(r)
    return {"ok": True, "all_verified": all(r["verified"] for r in results), "steps": results}


def cmd_date(d1, arg=None):
    a = date.fromisoformat(d1)
    if arg is None:
        return {"ok": True, "date": a.isoformat(), "weekday": a.strftime("%A")}
    if re.fullmatch(r"[+-]?\d+", arg):
        b = a + timedelta(days=int(arg))
        return {"ok": True, "result": b.isoformat(), "weekday": b.strftime("%A")}
    b = date.fromisoformat(arg)
    return {"ok": True, "days_between": (b - a).days}


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 1
    cmd, args = argv[1], argv[2:]
    table = {"calc": cmd_calc, "check": cmd_check, "solve": cmd_solve, "steps": cmd_steps, "date": cmd_date}
    try:
        out = table[cmd](*args)
    except KeyError:
        out = {"ok": False, "error": f"unknown command {cmd}"}
    except Exception as ex:  # noqa: BLE001
        out = {"ok": False, "error": f"{type(ex).__name__}: {ex}"}
    print(json.dumps(out, ensure_ascii=False, default=str))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
