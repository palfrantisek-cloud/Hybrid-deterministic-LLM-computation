---
name: hybrid-deterministic-llm-computation
description: On request only. Use ONLY when the user explicitly asks for verified, deterministic or hybrid computation (e.g. "verify this", "compute it deterministically", "use the math core", /hybrid-deterministic-llm-computation). Never apply it automatically to ordinary math.
disable-model-invocation: true
---

# Hybrid deterministic-LLM computation

**On request only.** Use this skill only when the user explicitly asks for it: phrases like "verify this", "compute deterministically", "use the math core", "prove it", "hybrid computation", or invoking the skill by name. Otherwise answer normally, without the core or the labels. Once it has been requested, keep using it for the rest of the conversation until the user says to stop.

When active: whenever a task contains a calculation, never produce the number from memory or mental arithmetic. Classify the task, use the deterministic core where it applies, and label every numeric answer with how it was obtained.

## 1. Get the core

- If `scripts/core.py` exists next to this SKILL.md, use it.
- Otherwise write the code from **Appendix: core.py** below, unchanged, to a scratch file named `core.py`, and use that.
- It needs Python 3 and SymPy (`pip install sympy`; add `--break-system-packages` if pip refuses).
- If code cannot run in this environment, say so and label every number `ⓘ LLM reasoning — not machine-verified`.

Commands (each prints JSON):

| Command | Use for |
|---|---|
| `python core.py calc "<expr>"` | exact value of an expression |
| `python core.py check "<expr>" "<claimed>"` | is a claimed value correct? |
| `python core.py solve "<equation>" [var]` | solve, then check each root by substitution |
| `python core.py steps file.json` (or `-` for stdin) | check a list of `{"label","expr","claimed"}` steps |
| `python core.py date 2026-09-23 +30` / `date A B` | date arithmetic and day counts |

Syntax: `+ - * / ^ % ( )`, `15%` means 0.15, `2x` means 2*x, `1,250` means 1250. Decimals are exact (0.1+0.2 = 3/10). Functions: sqrt, cbrt, abs, exp, log, ln, log10, sin, cos, tan, asin, acos, atan, factorial, floor, ceil, round(x, n), min, max, gcd, lcm, binomial. Constants: pi, e. Input is parsed without `eval`, so passing text from the user is safe.

## 2. Classify the task

**A. Simple / fully computable.** The whole answer is a calculation: arithmetic, percentages, VAT, interest, averages, totals, conversions with a known factor, equation solving, date differences.
→ Turn it into an expression and run `calc`, `solve` or `date`. Report the core's result, rounded only at the end.

**B. Complex / judgement.** Interpretation, strategy, writing, estimates from incomplete data, anything without a single checkable number.
→ Reason as an LLM normally. If an incidental number shows up (e.g. "about 3 × 40 hours"), still compute it with `calc`.

**C. Hybrid.** The LLM must decide *what* to compute (choose a model, formula or sequence of steps), and the steps can then be computed.
→ 1) Write out the plan and each step as an expression. 2) Put every numeric step into a `steps` JSON file with the value you expect. 3) Run `steps`. 4) Where a step fails, use the core's value, and carry it into later steps and re-run. 5) Where possible add an independent check: substitute the answer back into the original condition, confirm parts sum to the total, or compute the same result a second way.

## 3. Label the result

End each numeric answer with exactly one of these notes:

- `✔ Computed deterministically` — class A. The core produced the result.
- `✔ Verified by deterministic core — N/N calculation steps checked` — class C, all steps passed (add "and solution confirmed by substitution" when `solve` confirmed it).
- `⚠ Corrected by deterministic core` — class C, the core disagreed with the first attempt. Briefly state what changed.
- `ⓘ LLM reasoning — not machine-verified` — class B, or no check was possible.

Wording rules:
- Say **"proved"** only when a check logically proves the claim: an equation solution confirmed by substitution, or an exact identity (`how: exact`).
- A "verified" note means **the arithmetic was checked**. It does not mean the approach, the assumptions or the input data were checked. In class C, name the assumptions in one line (e.g. "Assumes monthly compounding").
- If `check` reports `how: rounded to N dp`, the claimed value is a correct rounding. Show the rounded figure.
- Never label a result verified when the core returned `ok: false`. Fix the expression, or fall back to the unverified label.

## 4. Examples

*"What is 17.5% of £2,340?"* → A → `calc "2340*17.5%"` → **£409.50** · ✔ Computed deterministically

*"Should we lease or buy the van?"* → B, with a hybrid part: reason about the trade-offs as an LLM. Put the cost comparison (lease total vs purchase minus resale) through `steps`. Label the cost figures ✔ verified and the recommendation ⓘ LLM reasoning.

*"A tank fills in 6 h, drains in 9 h — how long to fill with both open?"* → C → plan: rate 1/6 − 1/9 = 1/18 per hour → `solve "t*(1/6-1/9)=1"` → **18 hours** · ✔ Verified by deterministic core — solution confirmed by substitution (proved for the stated model; assumes constant rates).

## Appendix: core.py

```python
#!/usr/bin/env python3
"""Deterministic core: exact, reproducible math for an LLM to call and to verify against.

Commands (all print JSON):
  calc   "<expr>"                         exact value of an expression
  check  "<expr>" "<claimed>"             does expr equal the claimed value?
  solve  "<equation>" [var]               solve, then verify each root by substitution
  steps  <file.json | ->                  verify a list of {"label","expr","claimed"} steps
  date   "<YYYY-MM-DD>" [+/-days | "<YYYY-MM-DD>"]   date arithmetic / difference

Input is parsed with a whitelisted AST walker (no eval), so it is safe on arbitrary text.
Syntax: + - * / ** ^ % ( ), 15% -> 0.15, decimals are exact (0.1 + 0.2 == 3/10).
Functions: sqrt, cbrt, abs, exp, log, ln, log10, sin, cos, tan, asin, acos, atan,
factorial, floor, ceil, round, min, max, gcd, lcm, binomial. Constants: pi, e.
"""
import ast, json, re, sys
from datetime import date, timedelta

try:
    import sympy as sp
except ImportError:  # pragma: no cover
    print(json.dumps({"ok": False, "error": "sympy missing: pip install sympy"}))
    sys.exit(2)

MAX_EXP = 10_000          # guard against 10**10**10 style blow-ups
TOL = sp.Rational(1, 10**9)  # tolerance when the claim is a rounded decimal

FUNCS = {
    "sqrt": sp.sqrt, "cbrt": lambda x: sp.root(x, 3), "abs": sp.Abs, "exp": sp.exp,
    "log": lambda x, b=None: sp.log(x) if b is None else sp.log(x, b), "ln": sp.log,
    "log10": lambda x: sp.log(x, 10), "sin": sp.sin, "cos": sp.cos, "tan": sp.tan,
    "asin": sp.asin, "acos": sp.acos, "atan": sp.atan, "factorial": sp.factorial,
    "floor": sp.floor, "ceil": sp.ceiling,
    "round": lambda x, n=0: _round(x, n),
    "min": sp.Min, "max": sp.Max, "gcd": sp.gcd, "lcm": sp.lcm, "binomial": sp.binomial,
}
CONSTS = {"pi": sp.pi, "e": sp.E, "E": sp.E}


def _round(x, n=0):
    from decimal import Decimal, ROUND_HALF_UP
    q = Decimal(1).scaleb(-int(n))
    return sp.Rational(str(Decimal(str(sp.N(x, 50))).quantize(q, rounding=ROUND_HALF_UP)))


class Unsafe(ValueError):
    pass


def _pre(text: str) -> str:
    t = text.strip().replace("^", "**").replace("×", "*").replace("÷", "/").replace("−", "-")
    t = re.sub(r"(?<=\d),(?=\d{3}\b)", "", t)            # 1,000 -> 1000
    t = re.sub(r"(\d+(?:\.\d+)?)\s*%", r"(\1/100)", t)   # 15% -> (15/100)
    t = re.sub(r"(\d)\s*(?=[A-Za-z(])", r"\1*", t)          # 2x -> 2*x, 3(4) -> 3*(4)
    t = re.sub(r"\)\s*(?=[\w(])", ")*", t)                    # (a)(b) -> (a)*(b)
    return t


def _to_sym(node, symbols):
    if isinstance(node, ast.Expression):
        return _to_sym(node.body, symbols)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)) and not isinstance(node.value, bool):
        return sp.Rational(str(node.value)) if isinstance(node.value, float) else sp.Integer(node.value)
    if isinstance(node, ast.UnaryOp) and isinstance(node.op, (ast.UAdd, ast.USub)):
        v = _to_sym(node.operand, symbols)
        return v if isinstance(node.op, ast.UAdd) else -v
    if isinstance(node, ast.BinOp):
        a, b = _to_sym(node.left, symbols), _to_sym(node.right, symbols)
        op = node.op
        if isinstance(op, ast.Add): return a + b
        if isinstance(op, ast.Sub): return a - b
        if isinstance(op, ast.Mult): return a * b
        if isinstance(op, ast.Div):
            if b == 0: raise ZeroDivisionError("division by zero")
            return a / b
        if isinstance(op, ast.Mod): return sp.Mod(a, b)
        if isinstance(op, ast.FloorDiv): return sp.floor(a / b)
        if isinstance(op, ast.Pow):
            if b.is_number and abs(sp.N(b)) > MAX_EXP:
                raise Unsafe("exponent too large")
            return a ** b
    if isinstance(node, ast.Name):
        if node.id in CONSTS: return CONSTS[node.id]
        if re.fullmatch(r"[A-Za-z_]\w{0,15}", node.id):
            return symbols.setdefault(node.id, sp.Symbol(node.id))
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in FUNCS and not node.keywords:
        return FUNCS[node.func.id](*[_to_sym(a, symbols) for a in node.args])
    raise Unsafe(f"unsupported syntax: {ast.dump(node)[:60]}")


def parse(text, symbols=None):
    symbols = {} if symbols is None else symbols
    return _to_sym(ast.parse(_pre(text), mode="eval"), symbols)


def _fmt(v):
    v = sp.nsimplify(v) if v.is_Float else sp.simplify(v)
    out = {"exact": str(v)}
    if v.is_number:
        out["decimal"] = str(sp.N(v, 15))
    return out


def _equal(a, b):
    """True if equal exactly, or if b is a rounded decimal of a (reported as 'rounded')."""
    d = sp.simplify(a - b)
    if d == 0:
        return True, "exact"
    if d.is_number:
        diff = abs(sp.N(d, 50))
        # accept a claim rounded to the number of decimals it shows
        return (diff <= TOL, "numeric") if diff <= TOL else (False, "mismatch")
    return False, "not provably equal"


def cmd_calc(expr):
    v = parse(expr)
    return {"ok": True, "mode": "deterministic", "input": expr, **_fmt(v)}


def cmd_check(expr, claimed):
    a, b = parse(expr), parse(claimed)
    same, how = _equal(a, b)
    if not same and b.is_number and a.is_number and "." in claimed:
        # claimed may be rounded, e.g. 3.33 for 10/3: accept if it matches at its own precision.
        # Integer claims must match exactly (so "3" never passes for 3.4).
        m = re.search(r"\.(\d+)", claimed)
        places = len(m.group(1)) if m else 0
        if abs(sp.N(a - b, 50)) <= sp.Rational(1, 2 * 10**places):
            same, how = True, f"rounded to {places} dp"
    return {"ok": True, "verified": bool(same), "how": how, "input": expr,
            "claimed": claimed, "computed": _fmt(a)}


def cmd_solve(eq, var=None):
    syms = {}
    if "=" in eq and "==" not in eq:
        lhs, rhs = eq.split("=", 1)
        expr = parse(lhs, syms) - parse(rhs, syms)
    else:
        expr = parse(eq.replace("==", "-(") + (")" if "==" in eq else ""), syms)
    if not syms:
        raise Unsafe("no variable to solve for")
    x = syms[var] if var else sorted(syms.values(), key=str)[0]
    roots = sp.solve(expr, x)
    checked = [{"root": _fmt(r), "substitution_check": sp.simplify(expr.subs(x, r)) == 0} for r in roots]
    return {"ok": True, "variable": str(x), "solutions": checked,
            "verified": bool(roots) and all(c["substitution_check"] for c in checked)}


def cmd_steps(src):
    data = json.load(sys.stdin if src == "-" else open(src, encoding="utf-8"))
    results = []
    for i, s in enumerate(data, 1):
        try:
            r = cmd_check(s["expr"], str(s["claimed"]))
        except Exception as ex:  # noqa: BLE001
            r = {"verified": False, "error": str(ex)}
        r["label"] = s.get("label", f"step {i}")
        results.append(r)
    return {"ok": True, "all_verified": all(r["verified"] for r in results), "steps": results}


def cmd_date(d1, arg=None):
    a = date.fromisoformat(d1)
    if arg is None:
        return {"ok": True, "date": a.isoformat(), "weekday": a.strftime("%A")}
    if re.fullmatch(r"[+-]?\d+", arg):
        b = a + timedelta(days=int(arg))
        return {"ok": True, "result": b.isoformat(), "weekday": b.strftime("%A")}
    b = date.fromisoformat(arg)
    return {"ok": True, "days_between": (b - a).days}


def main(argv):
    if len(argv) < 2:
        print(__doc__); return 1
    cmd, args = argv[1], argv[2:]
    table = {"calc": cmd_calc, "check": cmd_check, "solve": cmd_solve, "steps": cmd_steps, "date": cmd_date}
    try:
        out = table[cmd](*args)
    except KeyError:
        out = {"ok": False, "error": f"unknown command {cmd}"}
    except Exception as ex:  # noqa: BLE001
        out = {"ok": False, "error": f"{type(ex).__name__}: {ex}"}
    print(json.dumps(out, ensure_ascii=False, default=str))
    return 0 if out.get("ok") else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv))
```
