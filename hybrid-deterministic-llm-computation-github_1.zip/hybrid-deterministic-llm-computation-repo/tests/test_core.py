"""Run with:  pip install -r requirements.txt pytest  &&  pytest"""
import json, pathlib, subprocess, sys

CORE = pathlib.Path(__file__).parents[1] / "hybrid-deterministic-llm-computation" / "scripts" / "core.py"


def run(*args, stdin=None):
    out = subprocess.run([sys.executable, str(CORE), *args], input=stdin,
                         capture_output=True, text=True, encoding="utf-8")
    return json.loads(out.stdout)


def test_exact_decimals():
    assert run("calc", "0.1+0.2")["exact"] == "3/10"


def test_percent_and_thousands():
    assert run("calc", "2,340 * 17.5%")["decimal"].startswith("409.5")


def test_check_catches_wrong_claim():
    assert run("check", "10/3", "3.4")["verified"] is False


def test_check_accepts_correct_rounding():
    r = run("check", "10/3", "3.33")
    assert r["verified"] and r["how"] == "rounded to 2 dp"


def test_integer_claim_must_be_exact():
    assert run("check", "59.97*20%", "12")["verified"] is False


def test_solve_is_checked_by_substitution():
    r = run("solve", "x^2-5x+6=0")
    assert r["verified"] and {s["root"]["exact"] for s in r["solutions"]} == {"2", "3"}


def test_steps():
    data = (pathlib.Path(__file__).parents[1] / "examples" / "invoice-steps.json").read_text()
    r = run("steps", "-", stdin=data)
    assert [s["verified"] for s in r["steps"]] == [True, True, False]  # 71.97 is wrong: 71.964 -> 71.96


def test_dates():
    assert run("date", "2026-01-01", "2026-12-25")["days_between"] == 358


def test_rejects_code_injection():
    assert run("calc", "__import__('os').system('echo hi')")["ok"] is False


def test_rejects_huge_exponent():
    assert run("calc", "10**10**10")["ok"] is False
